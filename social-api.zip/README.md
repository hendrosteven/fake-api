FakeRestAPI

# Howto composer
  - Make sure you already installed PHP, MySQL, Composer
  - $ git clone [repo url] [folder name]
  - $ cd [folder name]/www
  - $ edit file config/config.ini to your preference
  - $ composer install / composer udpate
  - $ composer run
  - open your browser and access to this url http://localhost:8080